<?php $__env->startSection('header'); ?>
  <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('isi'); ?>
  <div class="slider">
      <ul class="slides">
        <li>
          <img src="img/budaya1.jpg"> <!-- random image -->
          <div class="caption center-align">
            <h3>LESTARI BANYUMAS</h3>
            <h5 class="light grey-text text-lighten-3">Support Your Local Wisdom</h5>
          </div>
        </li>
        <li>
          <img src="img/budaya4.jpg"> <!-- random image -->
          <div class="caption right-align">
            <h3>LESTARI BANYUMAS</h3>
            <h5 class="light grey-text text-lighten-3">Support Your Local Wisdom</h5>
          </div>
        </li>
        <li>
          <img src="img/budaya3.jpg"> <!-- random image -->
          <div class="caption left-align">
            <h3>LESTARI BANYUMAS</h3>
            <h5 class="light grey-text text-lighten-3">Support Your Local Wisdom</h5>
          </div>

        </li>

      </ul>
    </div>

    <div class="row">
      <?php $__currentLoopData = $budaya; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


      <div class="col s3">
        <div class="card">
        <div class="card-image waves-effect waves-block waves-light">
          <img class="activator" src="img/budaya9.jpg">
        </div>
        <div class="card-content">
          <span class="card-title activator grey-text text-darken-4"><?php echo e($value->nama_budaya); ?><i class="material-icons right">more_vert</i></span>
          <p><a href="<?php echo e(route('detailtarianuser')); ?>">Read More</a></p>
        </div>
        <div class="card-reveal">
          <span class="card-title grey-text text-darken-4"><?php echo e($value->nama_budaya); ?><i class="material-icons right">close</i></span>
          <p><?php echo e($value->deskripsi_budaya); ?></p>
        </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
      
    </div>

    <script type="text/javascript">
    document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.slider');
    var instances = M.Slider.init(elems, instances);
    });


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>