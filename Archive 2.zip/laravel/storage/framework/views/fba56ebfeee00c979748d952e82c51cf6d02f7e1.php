<?php $__env->startSection('header'); ?>
  <?php echo $__env->make('headeradmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('isi'); ?>
<style media="screen">
  .margin{
    margin-top: 10px;
  }
</style>
<head>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.18/datatables.min.css"/>


</head>
<div class="pad ">


  <table id="table_id" class="display responsive-table">
          <thead>
            <tr>
                <th>No</th>
                <th>Foto</th>
                <th>Nama Wisata</th>
                <th>Deskripsi Wisata</th>
                <th>Action</th>
                <th>Konfirmasi</th>
                <th>Status</th>

            </tr>
          </thead>

          <tbody>
            <?php $__currentLoopData = $inputwisata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e(++$index); ?></td>
              <td><img src="<?php echo e(asset('storage/'.$value->foto)); ?>" style="width: 100px"></td>
              <td><?php echo e($value->nama); ?></td>
              <td><?php echo e($value->deskripsi); ?></td>

              <td>
                <table>
                    <a href="<?php echo e(route('detailinputwisata',['detailinputwisata'=>$value->id])); ?>"><button class="btn btn-success btn-small green accent-4">Show</button></a>
                                 <br>
                    

                                <form action="/deleteinputwisata/<?php echo e($value->id); ?>" method="post">
                                                      <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="_method" value="delete">
                                        <button class="btn btn-danger btn-small red accent-4 margin">Delete</button>
                                </form>
                </table>

              </td>
              <td>
                <table>
                  <form action="<?php echo e(route('konfirmasi',['konfirmasi'=>$value->id])); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <input type="hidden" name="_method" value="PUT">
                      <button class="btn btn-success btn-small green accent-4">Setujui</button>
                  </form>


                </table>

              </td>
              <td><?php echo e($value->status); ?></td>
            </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
</div>


<script type="text/javascript">
$(document).ready( function () {
    $('#table_id').DataTable();
} );


$('#myTable').DataTable( {
    responsive: true
} );

</script>
<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.18/datatables.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>