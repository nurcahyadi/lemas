
<?php $__env->startSection('header'); ?>
  <nav>
    <div class="nav-wrapper brown lighten-1">
      <a href="#" class="brand-logo" style="margin-left:10px;"> LEMAS </a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
        <li><a href="<?php echo e(route('homeadminbudaya')); ?>"><i class="material-icons left">folder_shared</i>Budaya</a></li>
        <li><a href="<?php echo e(route('homeadminsejarah')); ?>"><i class="material-icons left">library_books</i>Sejarah</a></li>
        <li><a href="<?php echo e(route('homeadminwisata')); ?>"><i class="material-icons left">add_a_photo</i>Wisata</a></li>
        <li><a href="<?php echo e(route('homeadminumkm')); ?>"><i class="material-icons left">local_mall</i>UMKM</a></li>
        
        
      </ul>
    </div>
  </nav>

<?php $__env->stopSection(); ?>
