<?php $__env->startSection('header'); ?>
  <?php echo $__env->make('headeradmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('isi'); ?>
  <!-- Page Layout here -->
    <div class="row">

      <div class="col s3">
        <!-- Grey navigation panel -->
        <br>

        <img src="<?php echo e(asset('storage/' .$sejarahshow->foto_sejarah)); ?>" style="width: 350px" >

        <a class="waves-effect waves-light btn-small" href="<?php echo e(route('homeadminsejarah')); ?>"><i class="material-icons left">home</i>Back to home</a>
      </div>

      <div class="col s9">
        <table class="table">

                                        <tr>
                                          <th>Nama Wisata</th>
                                          <td><?php echo e($sejarahshow->nama_sejarah); ?></td>
                                        </tr>

                                        <tr>
                                          <th>Deskripsi Wisata</th>
                                          <td><?php echo e($sejarahshow->deskripsi_sejarah); ?></td>
                                        </tr>



                                      </table>

      </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>