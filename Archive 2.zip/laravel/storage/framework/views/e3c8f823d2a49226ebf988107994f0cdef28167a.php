<?php $__env->startSection('header'); ?>
  <?php echo $__env->make('headeradmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('isi'); ?>
  <!-- Page Layout here -->
    <div class="row">

      <div class="col s3">
        <!-- Grey navigation panel -->
        <br>

        <img src="<?php echo e(asset('storage/' .$umkmshow->foto_umkm)); ?>" style="width: 350px" >

        <a class="waves-effect waves-light btn-small" href="<?php echo e(route('homeadminumkm')); ?>"><i class="material-icons left">home</i>Back to home</a>
      </div>

      <div class="col s9">
        <table class="table">

                                        <tr>
                                          <th>Nama Wisata</th>
                                          <td><?php echo e($umkmshow->nama_umkm); ?></td>
                                        </tr>

                                        <tr>
                                          <th>Deskripsi Wisata</th>
                                          <td><?php echo e($umkmshow->deskripsi_umkm); ?></td>
                                        </tr>

                                        <tr>
                                          <th>Alamat Wisata</th>
                                          <td><?php echo e($umkmshow->alamat_umkm); ?></td>
                                        </tr>

                                      </table>

      </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>