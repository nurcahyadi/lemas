<?php

use Faker\Generator as Faker;

$factory->define(App\Budaya::class, function (Faker $faker) {
    return [
        //
    ];
});
