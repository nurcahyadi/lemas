<?php

use Faker\Generator as Faker;

$factory->define(App\Sejarah::class, function (Faker $faker) {
    return [
        //
    ];
});
