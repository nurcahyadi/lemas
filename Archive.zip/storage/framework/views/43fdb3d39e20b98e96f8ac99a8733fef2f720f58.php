<?php $__env->startSection('header'); ?>
  <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('isi'); ?>

<div class="pad">
<a href=""> <button type="button" class="btn btn-primary" style="float: right; margin-right:20px; margin-top:20px;">Tambah</button></a>

  <table id="table_id" class="display responsive-table">
          <thead>
            <tr>
                <th>No</th>
                <th>Foto</th>
                <th>Nama Budaya</th>
                <th>Deskripsi</th>
                <th>Action</th>

            </tr>
          </thead>

          <tbody>
            <?php $__currentLoopData = $budaya; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e(++$index); ?></td>
              <td><img src="<?php echo e(asset('storage/'.$value->foto_budaya)); ?>" style="width: 100px"></td>
              <td><?php echo e($value->nama_budaya); ?></td>
              <td><?php echo e($value->deskripsi_budaya); ?></td>

              <td>
                

              </td>
            </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>

</div>

<script type="text/javascript">
$(document).ready( function () {
    $('#table_id').DataTable();
} );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>