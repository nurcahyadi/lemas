<?php

use Faker\Generator as Faker;

$factory->define(App\umkm::class, function (Faker $faker) {
    return [
        //
    ];
});
