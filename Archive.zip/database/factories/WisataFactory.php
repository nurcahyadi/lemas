<?php

use Faker\Generator as Faker;

$factory->define(App\Wisata::class, function (Faker $faker) {
    return [
        //
    ];
});
